create table userValidation(uid int primary key not null,password text not null);
