create table if not exists user(sysuserid INTEGER  primary key  not null ,userid int not null,username text,dob date,email text);

create table if not exists groups(groupid int primary key not null,sysgroupid int not null,groupname text);

create table if not exists members(memberid int primary key not null);

create table if not exists groupMembers(groupid int  not null references groups(groupid),memberid int not null references members(memberid),accessRight text not null references accessRights(accessRight),primary key(groupid,memberid,accessRight));

create table if not exists accessRights(accessRight text primary key not null,accessRightDescriptions text);

create table if not exists msgSourceStore(msgid INTEGER primary key,sysuserid INTEGER not null,msgtext text,msgTimeStamp datetime  DEFAULT CURRENT_TIMESTAMP,draftOrSent INTEGER,msgFrom INTEGER,FOREIGN KEY(sysuserid) REFERENCES user(sysuserid));

create table if not exists msgSinkStore(sysuserid INTEGER not null references user(sysuserid),userid int not null,msgid INTEGER not null references msgSourceStores(msgid),msgtext text,msgTimeStamp timestamp  DEFAULT CURRENT_TIMESTAMP,primary key(sysuserid,msgid));

create table if not exists msgAttachments(atchid int not null primary key,msgid int not null,atchname text,atchblob blob,FOREIGN KEY(msgid) references msgSourceStores(msgid));

create table if not exists membersLabelGroups(parentLabel text primary key not null,memberid int not null,label text not null,FOREIGN KEY(memberid) REFERENCES members(memberid),FOREIGN KEY(label) REFERENCES membersLabels(label));

create table if not exists membersMsgLabels(memberid int references members(memberid),msgid int references msgAttachments(msgid),label text references msgAttachments(label),primary key(memberid,msgid,label));

create table if not exists membersLabels(sysLabelNo INTEGER primary key not null,label text not null,memberid int not null,labelDescription text,uids text,FOREIGN KEY(memberid) REFERENCES members(memberid));

CREATE TABLE if not exists membersChildLabels(sysLabelNo INTEGER primary key not null,childlabel text  not null,plabel text not null,memberid int not null,labelDescription text, uids text,FOREIGN KEY(memberid) REFERENCES members(memberid));

create table if not exists servicesForUser(serviceId INTEGER primary key not null,ServiceType text,memberid int not null,FOREIGN KEY(memberid) REFERENCES members(memberid))



