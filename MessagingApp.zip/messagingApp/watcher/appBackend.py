import sys
import os, time
import sqlite3 as lite
import shutil
import imp
import json
import re
import hashlib
from datetime import datetime
invalidJsonFiles=[]

def validationDob(dob):
    rule=re.compile("^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$")
    if not rule.search(dob):
       return False
    else:
       return True

def validationPassword(password):
    rule=re.compile("^[A-Za-z0-9]\w{7,14}$")
    if not rule.search(password):
       return False
    else:
       return True

def validationEmailId(email):
    rule=re.compile("^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$")
    if not rule.search(email):
       return False
    else:
       return True

            
def validationUserId(userId):
    rule=re.compile("^[0-9]{10}$") 
    if not rule.search(userId):
       return False
    else:
       return True


def userNameValidation(name):
     for char in name:
         if not char.isalpha():
             return False
     return True

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def getSleepTime():
     getVarFromFile('/var/www/webPage/messagingApp/config.txt')
     time1=""
     time1= data.sleepTime
     return time1

def validateJsonFile(files,JsonFiles):
        
        with open(files) as jsonFile:
            try:    
                
                JsonFiles[files]=json.load(jsonFile)
            except ValueError, e:
                #print ("JSON object issue: %s") % e
                invalidJsonFiles.append(files)
  
        return (JsonFiles)
def forDatabaseConnection():
             getVarFromFile('/var/www/webPage/messagingApp/config.txt')
             databaseNameForUidAndPassword=data.databaseNameUidAndPassword
             mainschema=data.databaseForWebApp
             dirpath=data.targetDirectoryPath
             uidPasswordDatabasePath=databaseNameForUidAndPassword
             mainDatabasePath=mainschema
             con=lite.connect(mainDatabasePath)
             cur = con.cursor()
             con2=lite.connect(uidPasswordDatabasePath)
             cur2 = con2.cursor()
             cur2.execute("SELECT uid,password  from userValidation")
             return (cur2,cur,con,con2)
def forValidation(added):
                    
                    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
                    conWatcher = lite.connect(data.databaseNameWatcher)
  	            curWatcher = conWatcher.cursor() 
                    path=data.targetDirectoryPath
                    resPath=data.responseDir
                    for fname in added:
                        
                       validFiles={}
                       fpath=path
                       fpath+=fname[0]
                       rpath=resPath
                       rpath+=fname[0]
                       data1=""
                       
                       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
                      
                                           
                       if(fname[0][0]=="l"):
                              
                              loginResponse={}  
                              str1=forLogin(data1)
                              if(str1==True):
                                 loginResponse={fname[0]:1}
                                  
                                 
                              else:
                                  loginResponse={fname[0]:0}

                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(loginResponse)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)     

                       if(fname[0][0]=="r"):
                              registrationResponces={} 
                              str1=forRegistration(data1)
                              if(str1==True):
                                 registrationResponces={fname[0]:1}
                              else:    
                                 registrationResponces={fname[0]:0} 
                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(registrationResponces)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)       

                              
                       if(fname[0][0]=="c"):
                              
                              str1=forMessage(data1)
                              
                              if(str1==True):
                                   composeResponces={fname[0]:1}
                              else:
                                   composeResponces={fname[0]:0}
 
                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(composeResponces)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)

                       if(fname[0][0]=="e"):
                              str1=forEvent(data1)
                              
                              if(str1==True):
                                   eventResponces={fname[0]:1}
                                   print str1
                              else:
                                   print str1
                                   eventResponces={fname[0]:0}
 
                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(eventResponces)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)

                       if(fname[0][0]=="s"):
                              serviceRegistrationResponces={} 
                              str1=forServiceRegistration(data1)
                              if(str1==True):
                                serviceRegistrationResponces={fname[0]:1}
                              else:    
                                 serviceRegistrationResponces={fname[0]:0} 
                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(serviceRegistrationResponces)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)      
                       if(fname[0][0]=="u"):
                              serviceUnRegistrationResponces={} 
                              str1=forServiceUnRegistration(data1)
                              if(str1==True):
                                serviceUnRegistrationResponces={fname[0]:1}
                              else:    
                                 serviceUnRegistrationResponces={fname[0]:0} 
                              sql = 'DELETE FROM FileCollection WHERE FileName=?'
                              curWatcher.execute(sql,(fname[0],))
                              conWatcher.commit()
                              data1=json.dumps(serviceUnRegistrationResponces)
    			      f=open(rpath,"w+")
    			      f.write("%s"%(data1))
                              os.remove(fpath)       
 

                       if(fname[0][0]=="a"):
                             
                             labelResponces={}  
                             str1=forLabel(data1)
                              
                             if(str1==True):
                                   labelResponces={fname[0]:1}
                             elif(str1==2):
                                   labelResponces={fname[0]:2}
                             elif(str1==3): 
                                   labelResponces={fname[0]:3}
                             else:
                                   labelResponces={fname[0]:0}   
                             sql = 'DELETE FROM FileCollection WHERE FileName=?'
                             curWatcher.execute(sql,(fname[0],))
                             conWatcher.commit()
                             data1=json.dumps(labelResponces)
    			     f=open(rpath,"w+")
    			     f.write("%s"%(data1))
                             os.remove(fpath)


def forRegistration(validFiles):
          key=validFiles.keys()
          data1=validFiles
          for k in key:
             cur2,cur,con,con2=forDatabaseConnection()
             li=[]
             for id in cur2:
                    li.append(int(id[0]))      
             if int(data1["userId"]) in li:
    	              return False

             for item in key:
                  if(item=="name"):
                     name= userNameValidation(data1[item])
                  if(item=="userId"):
                     uid= validationUserId(data1[item])
                  if(item=="dateOfBirth"):
                     dob= validationDob(data1[item])
                  if(item=="reEnterPassword" or item=="password"):
                     password= validationPassword(data1[item])
                  if(item=="email"):
                     email= validationEmailId(data1[item])
       
             if ((name==True) and (uid==True) and (dob==True) and (password==True) and (email==True)):
                      userId=data1["userId"]
                      name=data1["name"]
                      dob=data1["dateOfBirth"]
                      email=data1["email"]
                      password=data1["password"]
                      for id in cur2:
                           li.append(int(id[0]))
                      if int(data1["userId"]) not in li:
                           cur2.execute('''INSERT INTO userValidation VALUES(?,?)''',(userId,password))   
   		           cur.execute('''INSERT INTO user(userid,username,dob,email) VALUES(?,?,?,?)''',(int(userId),str(name),dob,email))         
                           
                          
                                    
                           con2.commit()
                           con.commit()
                      return True
          return False
  

def forLogin(validFiles):
          key=validFiles.keys()
          data1=validFiles
          for k in key:
             cur2,cur,con,con2=forDatabaseConnection()
    	     list_uid=[]
    	     list_upwd=[]
             
    	     for user in cur2:
      	         list_uid.append(user[0])
      		 list_upwd.append(user[1])
    	     ch=zip(list_uid,list_upwd)
             for user in ch:
                 if user[0]==int(data1["userId"]) and user[1]==(data1["password"]):
                         return True
          return False
def forEvent(validFiles):
             data1=validFiles
             cur2,cur,con,con2=forDatabaseConnection()
             li=[]
             for id in cur2:
                    li.append(id[0])      
             userId=data1["userId"]
             eventName=data1["eventName"]
             dateForEvent=data1["dateForEvent"]


             con4 = lite.connect(data.databaseNameEvent)
  	     cur4 = con4.cursor()
  	     cur4.execute("create table if not exists eventLog(userid int not null,eventName text,dateForEvent date)")
             cur4.execute('''INSERT  INTO eventLog(userid,eventName,dateForEvent) VALUES(?,?,?)''',(userId,eventName,dateForEvent))
             con4.commit()
             return True         

def forMessage(validFiles):
          data1=validFiles
          key=validFiles.keys()
          for k in key:
             cur2,cur,con,con2=forDatabaseConnection()
             li=[]
             for id in cur2:
                    li.append(int(id[0]))
             
             if int(data1["ruserId"]) not in li:
                      return False

             else:  
                userId=data1["ruserId"]
                msg=data1["msg"]
                cur.execute("SELECT sysuserid  from user where userid=(?)",(userId,))
                sysid=0
                for i in cur:
                   sysid=i
                   
                cur.execute('''INSERT INTO msgSourceStore(sysuserid,msgtext,draftOrSent,msgFrom) VALUES(?,?,?,?)''',((sysid[0]),str(msg),1,(data1["suserId"])))                
                cur.execute("SELECT last_insert_rowid()")
                mid=0 
                for i in cur: 
                   mid=i
                suserId=data1["suserId"]
                cur.execute("SELECT sysuserid  from user where userid=(?)",(suserId,))
                sysid=0
                for i in cur:
                   sysid=i 
               
                cur.execute('''INSERT  INTO msgSinkStore(sysuserid,userid,msgid,msgText) VALUES(?,?,?,?)''',((sysid[0]),(data1["ruserId"]),mid[0],str(msg)))
                
                con.commit()

                return True




def forServiceRegistration(validFiles):
          data1=validFiles
          userId=data1["userId"]
          service=data1["service"]
          cur2,cur,con,con2=forDatabaseConnection()
          li=[]
          for id in cur2:
                    li.append(int(id[0]))
             
          if int(userId) not in li:
                      return False
          else:
               
               cur.execute('''INSERT INTO members VALUES(?)''',(userId,))
               cur.execute('''INSERT INTO servicesForUser(ServiceType,memberid)VALUES(?,?)''',(service,userId))
               con.commit()
               return True
                    

def forServiceUnRegistration(validFiles):
          data1=validFiles
          userId=data1["userId"]
          cur2,cur,con,con2=forDatabaseConnection()
          li=[]
          for id in cur2:
                    li.append(int(id[0]))
             
          if int(userId) not in li:
                      return False
          else:
               
               cur.execute('''delete from members where memberid=(?)''',(userId,))
               cur.execute('''delete from servicesForUser where memberid=(?)''',(userId,))
               con.commit()
               return True


def checkIsPresent(l1,l2):
     return set(l1).issuperset(set(l2))
         
def forLabel(validFiles):
    
    data1=validFiles
    uids=data1["ruserIds"] 
    uids=uids.split(',')   
    key=validFiles.keys()
    li=[]
   
    for k in key:
             cur2,cur,con,con2=forDatabaseConnection()
             labels=[]
             cur.execute("select label from membersLabels where memberid=(?)",(data1['suserId'],))
             for l in cur:
                      labels.append(l)
             if data1['lpname']=='':
                  
                  if data1['lname'] in labels:
                        return 2  
                  li=[]
                  for i in cur2:
                      li.append(int(i[0]))
                  uids=map(int,uids) 
                  if checkIsPresent(li,uids)==False:
                         return False
                  else:   
                     cur.execute('''insert into membersLabels(label,memberid,uids) values(?,?,?)''',((data1['lname']),(data1['suserId']),str(data1['ruserIds']))) 
                     con.commit()
                  return True   
             else:
                clabels=[]  
                checkPlabel=[] 
                cur.execute("select childlabel from  membersChildLabels where memberid=(?)",(data1['suserId'],))
                for l in cur:
                      labels.append(l)
                      clabels.append(l)
                for l in labels:
                    checkPlabel.append(l[0])
                if data1['lpname'] not in checkPlabel:
                        
                        return 3
                 
                if data1['lname'] in clabels:
                         return 2
                else:
                    
                    cur.execute('''insert into membersChildLabels (childlabel,plabel,memberid,uids) values(?,?,?,?)''',((data1['lname']),(data1['lpname']),(data1['suserId']),str(data1['ruserIds'])))
                    con.commit()              
                return True
                 
