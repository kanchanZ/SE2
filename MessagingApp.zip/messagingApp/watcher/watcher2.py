import sys
import os, time
import sqlite3 as lite
import shutil
import imp
import json
import re
import hashlib
import pyinotify
from datetime import datetime

def getVarFromFile(filename):
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)

def addDb(filePath):

              getVarFromFile('/var/www/webPage/messagingApp/config.txt')
 
              if filePath.endswith("json"):
       		con = lite.connect(data.databaseNameWatcher)
  		cur = con.cursor()
  		cur.execute("CREATE TABLE IF NOT EXISTS FileCollection (FileName TEXT, File_Data TEXT)")
               
                                     
                f1=open(filePath,'r')
                
                fname=filePath.split('/')
                fname=fname[-1]
                f1=f1.readlines()
                       
                cur.execute('''INSERT INTO FileCollection VALUES(?,?)''',(str(fname),str(f1)))
                con.commit()
                              
          

class myEventHandler(pyinotify.ProcessEvent):
     
     def process_IN_CREATE(self, event):
        f= event.pathname
        addDb(f)

     

def main():
    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    pathToWatch = data.targetDirectoryPath          
    wm = pyinotify.WatchManager()
    wm.add_watch(pathToWatch, pyinotify.ALL_EVENTS, rec=True)
    eh = myEventHandler()
    notifier = pyinotify.Notifier(wm, eh)
    notifier.loop()

if __name__ == '__main__':
    main()

            
