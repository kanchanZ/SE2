import sys
import os, time
import sqlite3 as lite
import shutil
import imp
import json
import re
import hashlib
from appBackend import forValidation 

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def getSleepTime():
     getVarFromFile('/var/www/webPage/messagingApp/config.txt')
     time1=""
     time1= data.sleepTime
     return time1


if __name__ == "__main__":   
        
        try:	
                
  		getVarFromFile('/var/www/webPage/messagingApp/config.txt')
  		con = lite.connect(data.databaseNameWatcher)
  		cur = con.cursor()
  		cur.execute("SELECT FileName from FileCollection")
                
  		before=[]
  		for f in cur:
   			 before.append(f)
  		while 1:
                         
       			after=[]
      			list1=[]
       			time1=getSleepTime()
       			time.sleep (time1)
       			cur.execute("SELECT FileName from FileCollection")
       			for f in cur:
            			after.append(f)
       			added = [f for f in after if not f in before]                 
                        forValidation(added)  
                                           
       			before=after
     			con.commit() 
        except Exception as e:
    		con.rollback()
    		raise e  
