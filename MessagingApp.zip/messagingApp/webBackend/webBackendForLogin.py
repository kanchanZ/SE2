import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
from css import c
from homepage import home
from loginFrontEnd import loginPage
from loginFrontEnd import relogin,loginNotAllow

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def login():     
     return loginPage()

def checkIsPresent(fname):

    getVarFromFile('/var/www/webPage/messagingApp/config.txt')    
    resDirPath=data.responseDir
    responces = dict ([(f, None) for f in os.listdir (resDirPath)])
    added = [f for f in responces] 
    if fname in added:
       fpath=resDirPath
       fname1=fname[0:11]
       fname1+='.json' 
       fpath+=fname 
       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
      
       os.remove(fpath)
          
       if data1[fname]==1:    
           return home(int(fname[1:11])) 
       else:   
           return relogin()
    return redirect(fname) 

def checkId(req):
    info=req.form
    userId=info['uid'].value
    p=info['passid'].value
    getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
    keys=['userId','password']
    values=[userId,p]
    dictionary = dict(zip(keys,values))
    data1=json.dumps(dictionary)
    fname="l"
    fname+=str(userId)
    fname+=str(p)
    fname+=".json"
    path=data.targetDirectoryPath 
    path+=fname
    f=open(path,"w+")
    f.write("%s"%(data1))
    return checkIsPresent(fname) 
    
    


def checkStatus(req):
     info=req.form
     fname=info['fname'].value
     return checkIsPresent(fname)
     
 
     
def redirect(fname):
       return """<html><font color="red">OOPS Response is Not generated !!!</font>
              <body>
             <form action="checkStatus" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="fname" id="fname" value="%s"></p>

             <input type="submit" value="checkStatus" >
             </form>
      
             </body>
             </html>"""%(fname)

def logout(req):
      info=req.form
      return  loginPage() 
       
