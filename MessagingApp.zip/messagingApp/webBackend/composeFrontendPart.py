import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
from homepage import home
from loginFrontEnd import loginPage
import urllib

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)

def composeFrontEnd(suId):
     
     suserId=suId
     #=''.join(c for c in suId if '0' <= c <='9')
     
     return"""<!DOCTYPE html>
	 <html>
  	 <style>
                /* unvisited link */
                        a:link {
                           color: yellow;
                        }
                        /* mouse over link */
                       a:hover {
                         color: hotpink;
                       }
                          /* selected link */
                        a:active {
                         color: green;
                       }
                       /* visited link */
                       a:visited {
                        color: light pink;
                        
                       }

    	textarea {
                        left:20%%;  
       	                width: 99%%;
                	padding: 12px 15px;
    	                box-sizing: border-box;
    	                border: 2px solid #ccc;
                    	border-radius: 4px;
    	                background-color: #f8f8f8;
    	                resize: none;
    	         }
    	form { 
	        margin: 10 ; 
    	        width:1200px;
                height:100px  
            	background-color:#D1D1D1;
   	        position:absolute;
   	        top:10%%;
                left:50px;
      	       
	    }
    input[type=button], input[type=submit], input[type=reset] {
           background-color: #4CAF50;
           border: 2px solid;
           border-radius: 25px;
           color: white;
           padding: 16px 32px;
           text-decoration: none;
           margin: 4px 2px;
           cursor: pointer;
        }
	input[type=text] {
             	width: 20%%;
            	//padding: 12px 20px;
        	margin: 8px 0;
        	box-sizing: border-box;
    	}

  	</style>
	<body bgcolor="#6495ED" border="1">

	<h2>Send Message::</h2>

	<form action="sourceStore" method="GET" name="form_name" id="form_id" enctype="text/plain">
        	To:<br>
	<input type="text" name="name" placeholder="10 digit number userid"><br>
	        Message:<br><br>
	<textarea name="text"" rows="6" cols="53"></textarea>
	<br><br>
        <input type="hidden" name="suid" id="suid" value="%s">
	<input type="submit" value="Send">
	<input type="reset" value="Reset"><br><br>
        <a href="http://localhost/messagingApp/webBackend/composeFrontendPart/fromCompose?uid=%s"> Click Here to go Homepage</a><br><br>

	<br><br>
	</form>

	</body>
	</html>"""%(suserId,urllib.quote_plus(str(suserId)))
     
          

def fromCompose(req):   
   suserId=req.form
   suId=str(suserId)
   suserId=''.join(c for c in suId if '0' <= c <='9')
   return home(suserId) 

