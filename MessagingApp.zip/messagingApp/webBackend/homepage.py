import urllib
from userService import checkService,showHomeUi
def home(uid):
  
  if(checkService(uid)==True):
        
        val="Unsubscribe"
  else:
        
        val="Subscribe"
   
  return  showHomeUi(uid,val)


