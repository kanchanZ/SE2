import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib



def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def getMessagesFromSink(suserId):
          getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
          con = lite.connect(data.databaseForWebApp)
  	  cur = con.cursor()
          cur.execute("select sysuserid from user where userid=(?)",(suserId,))
          sysid=0
          fromid=[]
          msg=[]
          timestamp=[]
          for i in cur:
              sysid=i  
          if sysid!=0:
            cur.execute("select userid,msgtext,msgTimeStamp from msgSinkStore where sysuserid=(?)",(sysid[0],)) 
            for i in cur:
                 fromid.append(i[0])
                 msg.append(i[1])
                 timestamp.append(i[2])
          return (fromid,msg,timestamp)    

def getMessagesFromSorce(suserId):
          getVarFromFile('/var/www/webPage/messagingApp/config.txt')
          con = lite.connect(data.databaseForWebApp)
  	  cur = con.cursor()
          cur.execute("select sysuserid from user where userid=(?)",(suserId,))
          sysid=0
          fromid=[]
          msg=[]
          timestamp=[]
          for i in cur:
              sysid=i  
          if sysid!=0:
            cur.execute("select msgFrom,msgtext,msgTimeStamp from msgSourceStore where sysuserid=(?)",(sysid[0],)) 
            for i in cur:
                 fromid.append(i[0])
                 msg.append(i[1])
                 timestamp.append(i[2])
 
          return (fromid,msg,timestamp)    
 
