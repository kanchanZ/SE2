from homepage import home
import urllib
def frontEndApply(info):
       
      suserId=info['fname'].value
      labels=info['labels'].value
      labels=labels.split(',')
      html=''  
      html+='	         <head>'
      html+=			 '<script>'
      html+=		 'function user(){' 
      html+=		       'var checkTo=/^[0-9]{10}$/;' 
      html+= 		'var chk1=document.getElementById("uid").value;'
      html+=		 'var element=document.getElementById("ie");'
      	
      html+=  	'chk=chk1.split(",");'
      html+=  	'for(var i=0;i<chk.length;i++){'
       
      html+=   	'if(!checkTo.test(chk[i]))'
      html+=   	'{'
      html+=   	'document.getElementById("ie").innerHTML="<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;"+"Invalid user ID:"+chk[i];'
      html+=   	'element.style.color="red";'
      html+=   	'document.getElementById("uid").value=""'
      html+=   	'return false;'
      html+=   	'}'
      html+=   	'else'
      html+=    	'{'
      html+=    	'document.getElementById("ie").innerHTML="";'
      html+=   	'// return true;'
      html+=  	' }'
      html+= 		'}'
      html+=		'return true;' 
      html+=		'}' 
     
      html+=   	'function userName(){'
	
      html+= 	 	'var unameReg = /^[A-Za-z0-9]*$/;'
      html+=		'var uname = document.getElementById("uname").value;'
      html+=		'var element = document.getElementById("nerror");'
      html+= 		'if (!(unameReg.test(uname))){'
      html+=		'document.getElementById("nerror").innerHTML="<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;"+"Invalid Label Name...";'
      html+=  	'  element.style.color="red"'
      html+=  	 ' document.getElementById("uname").value = ""'
      html+= 		'return false;'
      html+=		'}'
      html+= 		'else'
      html+=		'{'
      html+=  	'document.getElementById("nerror").innerHTML="";'
      html+=		'return true'
      html+=		'}'
      html+=		'}'
	
   
      html+=		'</script> '

      html+=    	'</head>'

      html+=      	'	<style>'

      html+=		'input[type=textarea] {'
     
      html+=           '	        left:50px;'
      html+=          '	         width: 500px;'
      html+=          '	         height: 250px; '   
      html+= 	        '	      	padding: 12px 15px;'
      html+=	        '	        box-sizing: border-box;'
      html+=	        '	        border: 2px solid #ccc;'
      html+=          '	    	border-radius: 4px;'
      html+=	        '	        background-color: #f8f8f8;'
    	        	      
      html+=	        '	 }'
	
      html+=	'	form { '
      html+=	 '       	margin: 10 ;' 
      html+=	  '      	width:1200px;'
      html+=     '     	height:100px  '
      html+=      '		background-color:#D1D1D1;'
      html+=	     '   	position:absolute;'
      html+=	      '  	top:10%%;'
      html+=         ' 	left:50px;'
      	       	
      html+=	    	'	}'
      html+=		 'input[type=button], input[type=submit], input[type=reset] {'
      html+=     	'	background-color: #4CAF50;'
      html+=     	'	border: 2px solid;'
      html+=     	'	border-radius: 25px;'
      html+=     	'	color: white;'
      html+=     	'	padding: 16px 32px;'
      html+=     	'	text-decoration: none;'
      html+=     	'	margin: 4px 2px;'
      html+=   	'	  cursor: pointer;'
      html+=  	'	}'
    
      html+='		input[type=text] {'
      html+= '    			width: 440px;'
      html+=  '  			padding: 10px 15px;'
      html+='			margin: 8px 0;'
      html+= '       		left:20px;'
      html+='			box-sizing: border-box;'
      html+='		 	}'
     
      html+='		 option{' 
      html+='                   display: none;'
      html+= '    		width: 100px;'
      html+= '    		color: black;'
      html+= '    		visiblity: visible;'
      html+= '    		display: block;'
      html+= '    		cursor: pointer;'
      html+= '    		border:2px;'
      html+= '                  border-radius: 3px;'

      html+=  '  		padding: 5px 5px;'
      html+='			margin: 8px 0;'
      html+= '       		border-color:red;'
      html+='			box-sizing: border-box;'
      html+='		 	}'

      html+='                    select:focus {'
      html+='                               outline: none; /* removing default browsers outline on focus */'
      html+='                         }'
     
      html+='input[type=text] {'
      html+= '               left:40px;'  
      html+=  '              width: 30%%;'
      html+=   '     	padding: 12px 15px;'
      html+=    '            box-sizing: border-box;'
      html+=     '           border: 2px solid #ccc;'
      html+=      '      	border-radius: 4px;'
      html+=       '         background-color: #f8f8f8;'
      html+=        '        resize: none;'
      html+=       	         '}'
     

      html+=' 			</style>'

      html+='    		 <body bgcolor="#87CEFA">' 
      html+='   		<h2>'
      html+='    		Please Enter Information For Label :<br>'
      html+='  		</h2>  '
      html+=' 		<form method="post" action="http://localhost/messagingApp/webBackend/webBackendForCreateLabel/applyLabel" id="lpname">'
      html+=' 		Enter User Ids:&nbsp;  &nbsp &nbsp'
      html+=	'<input type="text" id="uid" name="uids" onblur="user()" placeholder="Enter user id s separated by ","" required/><span id="ie"></span><br>'
       
     
      html+='	Enter  Msg Text: &nbsp '
      html+='	<input type="text" name="msg" placeholder="ex.any message"/><br>'
    
      html+= '        Name for Label :&nbsp '
      html+='	<input type="text" id="uname"  name="lname" onblur="userName()" placeholder="ex.PUCSD" required/> <span id="nerror"></span><br>      '
      html+='Parent Label:&nbsp &nbsp &nbsp &nbsp ' 
      html+=' <select name="lpname">'
      for i in range(0,len(labels)):
               
               html+='<option value="%s">%s</option>'%(labels[i],labels[i])
      html+=	'</select>'  
      html+= '       <p><input type="hidden" name="fname" id="fname" value="%s"></p>'
      html+='	<input type="submit" value="submit" >   '
      html+='	<input type="reset" value="Reset" ><form>     '
      html+='	<a href="http://localhost/messagingApp/webBackend/frontEndForLabel/fromLabel?uid=%s"> Click Here to go Homepage</a><br><br>'
      html+='	</form></body>'
      
      return 	"""</html>%s</html>"""%(html%(suserId,urllib.quote_plus(str(suserId)))) 
           

def fromLabel(req):   
   suserId=req.form
   return home(suserId['uid'].value) 

