l=[]
show=[]
show.append('<ul id="nestedlist">')
li=[]
lst=[]
l1=[]

def index(key,d,uid):

       
       str1=''     
       str1+='<head><style>'
       str1+='.submit1'
       str1+= '{background-color: #4CAF50;'
       str1+='   border: 2px solid;'
       str1+='   border-radius: 25px;'
       str1+= '  color: black;'
       str1+='    width: 10em;  height: 2em;'
       str1+='   text-decoration: none;'
       str1+='margin:-4px -2px;'
       str1+='cursor: pointer;'
       str1+='}' 
       str1+='ul,li{'
       str1+='text-indent:10px'
       str1+='margin-top: 10px;'
       str1+='margin-left: 80px;'
       str1+='list-style: square inside;' 
       str1+='}</style></head>'  
       show=fun1('',key,d,uid)
       
       for i in show:
          str1+=''.join(i)
    
       return str1       
def fun1(s,key,d,uid):
          
            for k in key:
              if not k in li:
                if d[k]==s:
                     li.append(k)            
                     l.append(k)
                     
                     show.append('<form action="display" id="form_id" method="post"  name= "myform" >')
                     show.append('<p><input type="hidden" name="uid" id="uid" value="%s"></p>'%uid) 
                     show.append('<input id="edit1" type="submit" name="edit" class="submit1" value="%s">' % k)
                     show.append('</form>')
                     show.append('<ul type="square">')
                     fun1(k,key,d,uid)
            show.append('</ul>')
            show.append('</li>')
            return show


def fun2(s,key,d,child,check):
          for k in key:
            if not k in check:
              if d[k]==s:
                 check.append(k)            
                 child.append(k)
                 fun2(k,key,d,child,check)

          return child
