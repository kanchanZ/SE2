import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from homepage import home
from appBackendForLabelService import getAllLabels,getMessagesFromSorceStore
 


def getTableI(data1,data2,data3, row_length):
    show='</form>'
    show+= '<table border=1 cellpadding="5" cellspacing="5" bgcolor="pink">'
    show+='<tr><th>msgFromId</th><th>msgText</th><th>TimeStamp</th></tr>'
    for i in range(0,len(data1)):
        show+= '<tr><td>%d</td>' % data1[i]
        show+= '<td>%s</td>' % data2[i]
        show+= '<td>%s</td></tr>' % data3[i]
    show+= '</table><br>'
    show+='<a href="http://localhost/messagingApp/webBackend/webBackendForLabel/fromLabel?uid=%s">For Home Click Here </a><br><br></form>'
    return show



def checkStatus(req):
    info=req.form
    fromIds=info['fname'].value
    userId=info['fname1'].value 
    fromIds=fromIds.split(',')
    fromId,msg,timeStamp=getMessagesFromSorceStore(userId,fromIds) 
    show=''
    show+=getTableI(fromId,msg,timeStamp,len(fromId))
    return """<html>%s</html>"""%(show%urllib.quote_plus(str(userId)))



def fromLabel(req):
     info=req.form
     suserId=info['uid'].value
     return home(suserId) 




def getTable(data1,users,suserId,row_length):

        s=''
	s+='<body>'
	s+='<table id="table1" border="1">'
	s+='<thead>'
	s+='      <tr>'
	s+=         ' <th>Labels'
	s+='    </thead>'
	s+='    <tbody>'
        for i in range(0,len(data1)):
 
          s+=' <tr>' 
          s+='<td>'
          s+='     <form action="checkStatus" id="form_id" method="post"  name= "myform" >'
                 
          s+=  '  <p><input type="hidden" name="fname" id="fname" value="%s"></p>' % users[i]
          s+='       <p><input type="hidden" name="fname1" id="fname1" value="%s"></p>' % suserId 
          s+='       <input id="edit1" type="submit" name="edit" value="%s">' % data1[i]
          s+='     </form>'
          s+='  <tr>'
        
        s+='</tbody>'
        s+='</table>'
        s+='</body>'
        return s 
       
def label(req):
     info=req.form
     data=info['id'].value
     suserId=''.join(c for c in data if '0' <= c <='9') 
     labels,aplayFor=getAllLabels(suserId)
     show='' 	
     show+=getTable(labels,aplayFor,suserId,len(labels))
     show+='<a href="http://localhost/messagingApp/webBackend/webBackendForLabel/fromLabel?uid=%s>For Home Click Here </a><br><br></form>'
     return """<html>%s</html>"""%(show%urllib.quote_plus(str(suserId)))


