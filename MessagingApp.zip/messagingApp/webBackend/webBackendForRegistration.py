import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
from registrationFrontEnd import registrationForm

def registration():
              return registrationForm()  

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)

def checkIsPresent(fname):

    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    resDirPath=data.responseDir
    login=data.loginPath
    register=data.registrationPath
    responces = dict ([(f, None) for f in os.listdir (resDirPath)])
    added = [f for f in responces] 
    if fname in added:
       fpath=resDirPath
       fpath+=fname
       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
      
       os.remove(fpath)
       if data1[fname]==1:    
           return """<html>
                	<body>
                	<center><h1>Registration Done Succesfully!!</h1></center>
                	<p><center><a href="%s">For Go To Login Page click here</a></center></p>
                	</body>
                	</html>""" %(login)
       else:
           return """
 			<html>
	                   <body> <font color="red">!!! UID IS ALREADY EXISTS PLEASE TRY WITH DIFFERENT UID!!!</font> 
        	             <br>
        	            <a href="%s">CLICK HERE TO GO BACK </a>
			   </body>	
        	           </html>"""%(register)


    return redirect(fname) 




def funprint(req):
        getVarFromFile('/var/www/webPage/messagingApp/config.txt')
        info=req.form
        name=info['uname'].value
        userId=info['uid'].value
        password=info['passid'].value
        rpassword=info['rpassid'].value   
        dob=info['dob'].value
        email=info['email'].value
        keys=['name','userId','password','reEnterPassword','dateOfBirth','email']
        values=[name,userId,password,rpassword,dob,email]
        dictionary = dict(zip(keys, values))
        data1=json.dumps(dictionary)
        fname="r" 
        fname+=str(userId)
        fname+=str(password)
        fname+=".json"
        path=data.targetDirectoryPath
        path+=fname
        f=open(path,"w+")
        f.write("%s"%(data1))
        return checkIsPresent(fname)
        
def checkStatus(req):
     info=req.form
     fname=info['fname'].value
     return checkIsPresent(fname)
     
 
     
def redirect(fname):
       return """<html><font color="red">OOPS Response is Not generated !!!</font>
              <body>
             <form action="checkStatus" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="fname" id="fname" value="%s"></p>

             <input type="submit" value="checkStatus" >
             </form>
      
             </body>
             </html>"""%(fname)

