from appBackendForInboxAndSentbox import getMessagesFromSorce
from homepage import home
import urllib
import json

def getTable(data1,data2,data3, row_length):
   
    show='<html><body bgcolor="#6495ED">' 
    show='</form>'
    show+= '<table border=1 cellpadding="5" cellspacing="5" bgcolor="#87CEFA">'
    show+='<tr><th>msgFromId</th><th>msgText</th><th>TimeStamp</th></tr>'
    for i in range(0,len(data1)):
        show+= '<tr><td>%d</td>' % data1[i]
        show+= '<td>%s</td>' % data2[i]
        show+= '<td>%s</td></tr>' % data3[i]
    show+= '</table><br>'
    show+='<a href="http://localhost/messagingApp/webBackend/webBackendForInbox/fromInbox?uid=%s">For Home Click Here </a><br><br></form></body>'
    return show


def inbox(req):
     info=req.form
     data=info['id'].value
     suserId=''.join(c for c in data if '0' <= c <='9')
     fromid,messages,timeStamp= getMessagesFromSorce(suserId)
     show=''
     show+=getTable(fromid,messages,timeStamp,len(fromid))
     return """<html>%s</html>"""%(show%urllib.quote_plus(str(suserId)))

def fromInbox(req):
     info=req.form
     suserId=info['uid'].value
     return home(suserId) 
