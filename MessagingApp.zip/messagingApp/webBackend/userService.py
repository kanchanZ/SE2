import sys
import os, time
import sqlite3 as lite
import shutil
import imp
import json
import re
import hashlib
import urllib
from datetime import datetime

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def checkService(userId):
    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    mainschema=data.databaseForWebApp  
    con=lite.connect(mainschema)
    cur = con.cursor()
    cur.execute("select memberid from members")
    mem=[]
    
    for m in cur:
          mem.append(m[0])
    
    if int(userId)  in mem:
          return True
    else:
          return False


def showHomeUi(uid,val):
  getVarFromFile('/var/www/webPage/messagingApp/config.txt')
  if val=="Unsubscribe":
      return"""<html>
             <style>   /* unvisited link */
                        a:link {
                           color: yellow;
                        }
                        /* mouse over link */
                       a:hover {
                         color: hotpink;
                       }
                          /* selected link */
                        a:active {
                         color: green;
                       }
                       /* visited link */
                       a:visited {
                        color: light pink;
                        
                       }

        textarea     {
                	width: 99%%;
    	             
    	                box-sizing: border-box;
    	                border: 2px solid #ccc;
    	                border-radius: 4px;
                        background-color: #f8f8f8;
    	                resize: none;
    	             }
    	.form1         { 
                        //padding: 9px 9px;
                   	margin: 0 auto; 
                        //width:300px;
                       	background-color: #E6E6FA;
                  	position:fixed;
                 	top:72%%;
                 	left:10%%;
   	                //width:250px;
                       	background-color: lightblue;
  	                border: 2px groove;
	             }
    input[type=text] {
    	                 width: 97%%;
    	                //padding: 12px 20px;
                       	margin: 8px 0; 
                  	box-sizing: border-box;
                     }
	h5         {
                        left: 0px;
                        top: 500px; 
                  	margin:50px;
    	                position=absolute;
                        font-size: 150%%; 
	           }
	h1         {
             	        position: absolute;
	                left: 10px;
                        top: 400px;
	                font-size=150%%;
                        margin:20px; 
                   }

	p         {
             	        position: absolute;
	                left: 0px;
                        top: 70px;
	                font-size=50px;
                        margin:30px;
                        font-color:#00FFFF;
                        font-weight:bold;  
                   }

	h3         {
             	        position: absolute;
	                left: 1100px;
                        top: 10px;
	                font-size:150%%;
                        margin:20px;
                   }

          input[type=submit] {
                        background-color: #4CAF50; /* Green */
                        border: solid;
                        color: white;
                        padding: 10px 20px;
                        text-align: center;
                        text-decoration: none;
                        display: block;
                        font-size: 16px;
                        border-radius: 2px;
                        latter-spacing:1px;
                        top:150 
                   }

          input[type=submit]:hover{
                    color:red;    
                    top:500px           
                  } 
	
       body {
               padding: 0;
               margin: 0; 
           }
    border {border:1px solid #cccccc;}

  	</style>
        	
	<body bgcolor="#87CEFA" border="2">
        
      
 <p style="font-size:34px; color:#736AFF; font-weight:bold; font-style:italic;">
        Welcome to Messanger::</p>
	<h5><br><br><br><br>
  	<a href='http://localhost/messagingApp/webBackend/webBackendForCompose.py/compose?id=%s'>Click Here to Compose Massage!</a><br><br>
	<a href='http://localhost/messagingApp/webBackend/webBackendForInbox.py/inbox?id=%s'>Click hare to view Inbox!</a><br><br>
	<a href='http://localhost/messagingApp/webBackend/webBackendForSentbox.py/sentbox?id=%s'>Click here to view SentBox!</a><br><br>
        <a href='http://localhost/messagingApp/webBackend/webBackendForEvent.py/event?id=%s'>Click here to Create And View Event!</a><br><br>
        <a href='http://localhost/messagingApp/webBackend/webBackendForShowLabel.py/label?id=%s'>Click here to create and view Labels!</a>
	</h5>
            <h3>
           <a href="http://localhost/messagingApp/webBackend/webBackendForLogin.py/logout?id=%s"><font color='blue'>LOGOUT</font></a>
	 </h3>
         </body>
        <center><form action="http://localhost/messagingApp/webBackend/webBackendForServices/serviceRegistration" id="yes" method="post"  name= "myform">
                <p><input type="hidden" name="fname" id="fname" value="%s"></p> 
		<input class="button" type="submit" name="chk" value="%s" ></input></form></center>
                
	</html>"""% (urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),val)



 



  else:
      return """<html>
             <style>   /* unvisited link */
                        a:link {
                           color: yellow;
                        }
                        /* mouse over link */
                       a:hover {
                         color: hotpink;
                       }
                          /* selected link */
                        a:active {
                         color: green;
                       }
                       /* visited link */
                       a:visited {
                        color: light pink;
                        
                       }

        textarea     {
                	width: 99%%;
    	             
    	                box-sizing: border-box;
    	                border: 2px solid #ccc;
    	                border-radius: 4px;
                        background-color: #f8f8f8;
    	                resize: none;
    	             }
    	.form1         { 
                        //padding: 9px 9px;
                   	margin: 0 auto; 
                        //width:300px;
                       	background-color: #E6E6FA;
                  	position:fixed;
                 	top:50%%;
                 	left:10%%;
   	                //width:250px;
                       	background-color: lightblue;
  	                border: 2px groove;
	             }
    input[type=text] {
    	                 width: 97%%;
    	                //padding: 12px 20px;
                       	margin: 8px 0; 
                  	box-sizing: border-box;
                     }
	h5         {
                        left: 0px;
                        top: 500px; 
                  	margin:50px;
    	                position=absolute;
                        font-size: 150%%; 
	           }
	h1         {
             	        position: absolute;
	                left: 10px;
                        top: 400px;
	                font-size=150%%;
                        margin:20px; 
                   }

	p         {
             	        position: absolute;
	                left: 0px;
                        top: 70px;
	                font-size=50px;
                        margin:30px;
                        font-color:#00FFFF;
                        font-weight:bold;  
                   }

	h3         {
             	        position: absolute;
	                left: 1100px;
                        top: 10px;
	                font-size:150%%;
                        margin:20px;
                   }

          input[type=submit] {
                        background-color: #4CAF50; /* Green */
                        border: solid;
                        color: white;
                        padding: 10px 20px;
                        text-align: center;
                        text-decoration: none;
                        display: block;
                        font-size: 16px;
                        border-radius: 2px;
                        latter-spacing:1px;
                        top:150 
                   }

          input[type=submit]:hover{
                    color:red;    
                    top:500px           
                  } 
	
       body {
               padding: 0;
               margin: 0; 
           }
    border {border:1px solid #cccccc;}

  	</style>
        
	<body bgcolor="#87CEFA" border="2">
        

 <p style="font-size:34px; color:#736AFF; font-weight:bold; font-style:italic;">
        Welcome to Messanger::</p>
	<h5><br><br><br><br>
  	<a href='http://localhost/messagingApp/webBackend/webBackendForCompose.py/compose?id=%s'>Click Here to Compose Massage!</a><br><br>
	<a href='http://localhost/messagingApp/webBackend/webBackendForInbox.py/inbox?id=%s'>Click hare to view Inbox!</a><br><br>
	<a href='http://localhost/messagingApp/webBackend/webBackendForSentbox.py/sentbox?id=%s'>Click here to view SentBox!</a><br><br>
        <a href='http://localhost/messagingApp/webBackend/webBackendForEvent.py/event?id=%s'>Click here to Create And View Event!</a><br><br>
	</h5>
            <h3>
           <a href="http://localhost/messagingApp/webBackend/webBackendForLogin.py/logout?id=%s"><font color='blue'>LOGOUT</font></a>
	 </h3>
         </body>
        <div id="form1"><center><form action="http://localhost/messagingApp/webBackend/webBackendForServices/serviceRegistration" id="yes" method="post"  name= "myform">
                <p><input type="hidden" name="fname" id="fname" value="%s"></p> 
		<input class="button" type="submit" name="chk" value="%s" "></input>
                </form></center></div>
        
	</html>"""% (urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),urllib.quote_plus(str(uid)),val)



 

            
