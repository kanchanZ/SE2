from appBackendForInboxAndSentbox import getMessagesFromSink
from homepage import home
import urllib

def getTable(data1,data2,data3, row_length):
    show=''
    show='</form>'
    show+= '<table border=1 cellpadding="5" cellspacing="5" bgcolor="#87CEFA">'
    show+='<tr><th>msgTo</th><th>msgText</th><th>TimeStamp</th></tr>'
    for i in range(0,len(data1)):
        show+= '<tr><td>%d</td>' % data1[i]
        show+= '<td>%s</td>' % data2[i]
        show+= '<td>%s</td></tr>' % data3[i]
    show+= '</table><br>'
    show+='<a href="http://localhost/messagingApp/webBackend/webBackendForSentbox/fromSentbox?uid=%s">For Home Click Here </a><br><br></form>'
    return show


def sentbox(req):
     info=req.form
     data=info['id'].value
     suserId=''.join(c for c in data if '0' <= c <='9')
     mid,messages,timeStamp=getMessagesFromSink(suserId) 
     show=''
     show+=getTable(mid,messages,timeStamp,len(mid))
     return """<html>%s</html>"""%(show%urllib.quote_plus(str(suserId)))

def fromSentbox(req):
       info=req.form
       suserId=info['uid'].value
       return home(suserId) 
