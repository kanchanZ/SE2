

def registrationForm():
 return """<html>
   <head>
   <title>Javascript</title>
   <style>
         
      h2{
	background-color: #FEFFED;
	padding: 30px 35px;
	margin: -10px -50px;
	text-align:center;
	border-radius: 10px 10px 0 0;
	}
	hr{
	margin: 10px -50px;
	border: 0;
	border-top: 1px solid #ccc;
	margin-bottom: 40px;
	}
	div.container{
	width: 250px;
	height: 150px;
	margin:35px auto;
	font-family: 'Raleway', sans-serif;
	}
	input[type=text],[type=password],[type=date]{
	width: 100%;
	height: 40px;
	padding: 5px;
	margin-bottom: 25px;
	margin-top: 5px;
	border: 2px solid #ccc;
	color: #4f4f4f;
	font-size: 16px;
	border-radius: 5px;
	}
	label{
	color: #464646;
	text-shadow: 0 1px 0 #fff;
	font-size: 14px;
	font-weight: bold;
	}

	#btn_id,#btn_name,#btn_class,#btn_tag{
	font-size: 16px;
	background: linear-gradient(#ffbc00 5%, #ffdd7f 100%);
	border: 1px solid #e5a900;
	color: #4E4D4B;
	font-weight: bold;
	cursor: pointer;
	width: 47.5%;
	border-radius: 5px;
	margin-bottom:10px;
	padding: 7px 0;
	}
	#btn_id:hover,#btn_name:hover,#btn_class:hover,#btn_tag:hover{
	background: linear-gradient(#ffdd7f 5%, #ffbc00 100%);
	}
	#btn_name,#btn_tag{
	margin-left: 10px;
	}
	body {
  	line-height: 1;
	}

   </style>
   <script>

    function submit_by_id() {
	var uid = document.getElementById("uid").value;
        var uid = document.getElementById("uname").value;
	var passid = document.getElementById("passid").value;
	var rpassid = document.getElementById("rpassid").value;
	var dob = document.getElementById("dob").value;
	var email = document.getElementById("email").value;
	
	if (useremail() && username() && userpassid() && useruid() && userrpassid() && userdob()) // Calling validation function
	{
	alert("Submitted Successfully......");
	document.getElementById("form_id").submit(); //form submission

	}
	}

	function userUid(){
	var uidReg = /^[0-9]{10}$/;
	var uid = document.getElementById("uid").value;
	var element = document.getElementById("merror");
	if (!(uidReg.test(uid))){
          document.getElementById("merror").innerHTML="Invalid user id...";
          element.style.color="red"
          document.getElementById("uid").value = ""
	return false;
	}
	else
	{
        document.getElementById("merror").innerHTML="";
	return true;
	}
	}

        function userName(){
 	var unameReg = /^[A-Za-z]*$/;
	var uname = document.getElementById("uname").value;
	var element = document.getElementById("ferror");
	if (!(unameReg.test(uname))){
          document.getElementById("ferror").innerHTML="Invalid first Name...";
          element.style.color="red"
          document.getElementById("uname").value = ""
	return false;
	}
	else
	{
        document.getElementById("ferror").innerHTML="";
 	return true
	}
	}

	function userEmail(){
	var emailReg =/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var email = document.getElementById("email").value;
	var element = document.getElementById("eerror");
	if (!(emailReg.test(email))){
  	document.getElementById("eerror").innerHTML="Invalid EmailId...";
  	element.style.color="red"
  	document.getElementById("email").value = ""
        	return false;
	}
	else
	{
         document.getElementById("eerror").innerHTML="";
         return true;
	}
	}

  	function userDob()
	{
    	var dob = document.getElementById("dob").value;
    	var dobReg =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
        var date1=dob.split('/');
        var day=date1[0];
        var month=date1[1];
        var year=date1[2]; 
        
    	var element = document.getElementById("berror");
   	 if ((!dobReg.test(dob)) || day<1 || day>31  || month<1 || month>12 || year<1917 || year>2017){
        document.getElementById("berror").innerHTML="Invalid date of birth...";
        element.style.color="red"
        document.getElementById("dob").value = ""
           return false;
    	}
    	else {
         document.getElementById("berror").innerHTML="";
         return true
    	}
	}
	
        function userPassword()
	{
	var passid=document.getElementById("passid").value;
	var passidReg=  /^[A-Za-z0-9]\w{7,14}$/;
        //var passidReg=/^(?=.*[A-Z].*[A-Z])(?=.*[!@#$&*])(?=.*[0-9].*[0-9])(?=.*[a-z].*[a-z].*[a-z]).{8,}$/;
	var element = document.getElementById("lerror");
	if((!passidReg.test(passid)))
	{
        document.getElementById("lerror").innerHTML="Invalid password(password must contains atlist 8 character)...";
        element.style.color="red"
        document.getElementById("passid").value = ""
           return false;
    	}
    	else {
          document.getElementById("lerror").innerHTML="";
          return true;
    	}
	}

        function userRpassword()
 	{
	var passid=document.getElementById("passid").value;
	var rpassid=document.getElementById("rpassid").value;
	var element = document.getElementById("rerror");
	if(rpassid!=passid)
	{
        document.getElementById("rerror").innerHTML="re-entered password not match with your password...";
        element.style.color="red"
        document.getElementById("rpassid").value = ""
           return false;
    	}
    	else {
          document.getElementById("rerror").innerHTML="";
          return true;
    	}
 	}
   </script>

   </head>
   <body>
   <div class="container">
   <form action="funprint" method="post" name="form_name" id="form_id" class="form_class" >
   <h2>Registration Form</h2>
   <label> Name : </label>
   <input type="text" name="uname" id="uname" placeholder=" eg. abc" onblur="userName()" required/> <span id = 'ferror'></span></br>
   <label for="uid">User Id: </label>  
   <input type="text" name="uid" placeholder="10 digit number" id="uid" onblur="userUid()" required><span id='merror'></span> <br/>
   <label for="passid">Password:</label>
   <input type="password" name="passid" placeholder="minimum 8 character" id="passid" onblur="userPassword()"required/><span id='lerror'></span><br/>   <label for="rpassid">Re Enter Password:</label>
   <input type="password" name="rpassid"  id="rpassid" onblur="userRpassword()" required/><span id='rerror'></span><br/>
   <label for="dob">date of birth: </label>
   <input type="date" name="dob" id="dob" placeholder="dd/mm/yyyy" max="31/12/1999" onblur="userDob()" required/><span id='berror'> </span><br/>
   <label for=email">Email: </label>
   <input type="text" name="email" id="email" placeholder="abc@gmail.com" size="50" onblur="userEmail()" required/><span id='eerror'></span><br/>
   <input type="submit" value="Submit"/>
   <INPUT TYPE="reset" onClick="history.go(0)" VALUE="Reset">
   </form>
   </div>
   </div>
   </body>
   </html>"""

