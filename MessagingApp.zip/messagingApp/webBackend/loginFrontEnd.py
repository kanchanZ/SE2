import urllib

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)



def loginPage():
 getVarFromFile('/var/www/webPage/messagingApp/config.txt')
 return """<html>
  <head>
  <title>Login Form</title>
  <link rel="stylesheet" href="http://localhost/messagingApp/webBackend/css.py/c">
<script>
 function user(){ 
       var checkTo=/^[0-9]{10}$/; 
       var chk=document.getElementById("uid").value;
       var element=document.getElementById("ie");
         if(!checkTo.test(chk))
         {
         document.getElementById("ie").innerHTML="Invalid user ID";
         element.style.color="red";
         document.getElementById("uid").value="";
         return false;
         }
         else
          {
          document.getElementById("ie").innerHTML="";
          return true;
         }

}   
</script> 

  </head>
  <body>
  <section class="container">
    <div class="login">
      <h1>Login to Web App</h1>
      <form action="checkId" id="form_id" method="post"  name= "myform">

	<p><input type="text"  name="uid" id="uid"  placeholder="userId" onblur= "user()" required/> <span id='ie'></span></p>
        <p><input type="password" name="passid" id="passid" placeholder="Password" required/></p>

        <p class="submit"><input type="submit" name="commit" value="Login" onclick="subToValidate()"/>
        <input type="reset" name="reset" value="Reset"/></p>
      </form>
      
   
    <div class="Sign-up"><center>
      <p>Not Yet Joined? <a href="%s"> click here to signUp</a></p></center>
    </div>
    </section>
   </body>
   </html>"""%(data.registrationPath)

def relogin():
                getVarFromFile('/var/www/webPage/messagingApp/config.txt')
                
                return """<html>
		          <font color="red">UID Not Exists !!!</font><br>
                          <body>    
                          <a href="%s">CLICK HERE TO LOGIN AGAIN</a> 
       	                  </body>
                          </html>"""%(data.loginPath)
def loginNotAllow(userId):    
             getVarFromFile('/var/www/webPage/messagingApp/config.txt')
             return """<html>
		          <font color="red">SOME ONE ALREADY LOGIN !!!</font><br>
                          <body>    
                          <a href="%s?uid=%s">CLICK HERE TO LOGOUT</a> 
       	                  </body>
                          </html>"""%(data.logoutPath,urllib.quote_plus(str(userId)))

