

import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from frontEndForLabel import frontEndApply



def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def createLabel(req):
 info=req.form
 return frontEndApply(info)



def checkIsPresent(fname,suId):

    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    resDirPath=data.responseDir
    responces = dict ([(f, None) for f in os.listdir (resDirPath)])
    added = [f for f in responces] 
    if fname in added:
       fpath=resDirPath
       fpath+=fname
       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
      
       os.remove(fpath)
       if data1[fname]==1:    
            return """<html>
                	<body bgcolor="#6495ED"><form>
                	<center><h1>Label Created Successfully</h1></center>
                	<p><center><a href="%s?id=%s">Show Labels click here</a></center></p></form>
                	</body>
                	</html>"""%(data.showLabel,urllib.quote_plus(str(suId))) 
       elif data1[fname]==2:    
            return """<html>
                	<body><form>
                	<center><h1>Label is already Created </h1></center>
                	<p><center><a href="%s?id=%s">Show Labels click here</a></form></center></p></form>
                	</body>
                	</html>"""%(data.showLabel,urllib.quote_plus(str(suId))) 
       elif data1[fname]==3:    
            return """<html>
                	<body><form>
                	<center><h1>Parent Label is Not Exists </h1></center>
                	<p><center><a href="%s?id=%s">Show Labels click here</a></center></p></form>
                	</body>
                	</html>"""%(data.showLabel,urllib.quote_plus(str(suId))) 
  
       
       else:
           return """<html>
                   <body> <form><font color="red">Trying to apply lable for Incorrect Ids Please Try Again!!!</font> 
                     <br>
                    <a href="%s?id=%s">Go Back</a></form>
		   </body>	
                   </html>"""%(data.showLabel,urllib.quote_plus(str(suId)))        

    return redirect(fname,suId)



def applyLabel(req):
     info=req.form
     suid=info['fname'].value  
     ruids=info['uids'].value
     labelName=info['lname'].value
     plabelName=info['lpname'].value  
     text=info['msg'].value
     getVarFromFile('/var/www/webPage/messagingApp/config.txt')
     path=data.targetDirectoryPath
     keys=['suserId','ruserIds','lname','lpname','msg']
     values=[suid,ruids,labelName,plabelName,text]
     dictionary = dict(zip(keys, values))
     data1=json.dumps(dictionary)
     fname="a"
     fname+=str(suid)
     fname+=".json"
     path+=fname
     f=open(path,"w+")
     f.write("%s"%(data1))
     return checkIsPresent(fname,suid) 
    	       
def checkStatus(req):
     info=req.form
     fname=info['fname'].value
     suId=info['suid'].value
     return checkIsPresent(fname,suId)

def redirect(fname,suId):
       return """<html><center><font color="red">OOPS Response is Not generated !!!</font>
              <body>
             <form action="checkStatus" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="fname" id="fname" value="%s"></p>
              <p><input type="hidden" name="suid" id="suid" value="%s"></p>
             <input type="submit" value="checkStatus" >
             </form>
             </center>
             </body>
             </html>"""%(fname,suId)

