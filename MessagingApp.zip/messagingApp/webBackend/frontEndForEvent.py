import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
from homepage import home
from loginFrontEnd import loginPage
import urllib

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)

def frontEndForEvent(suId):
     
     suserId=suId
     #=''.join(c for c in suId if '0' <= c <='9')
     
     return"""<!DOCTYPE html>
	 <html>
         <head>
  	 <style>
                /* unvisited link */
                        a:link {
                           color: yellow;
                        }
                        /* mouse over link */
                       a:hover {
                         color: hotpink;
                       }
                          /* selected link */
                        a:active {
                         color: green;
                       }
                       /* visited link */
                       a:visited {
                        color: light pink;
                        
                       }

    	textarea {
                        left:20%%;  
       	                width: 99%%;
                	padding: 12px 15px;
    	                box-sizing: border-box;
    	                border: 2px solid #ccc;
                    	border-radius: 4px;
    	                background-color: #f8f8f8;
    	                resize: none;
    	         }
    	form { 
	        margin: 10 ; 
    	        width:1200px;
                height:100px  
            	background-color:#D1D1D1;
   	        position:absolute;
   	        top:10%%;
                left:50px;
      	       
	    }
    input[type=button], input[type=submit], input[type=reset] {
           background-color: #4CAF50;
           border: 2px solid;
           border-radius: 25px;
           color: white;
           padding: 16px 32px;
           text-decoration: none;
           margin: 4px 2px;
           cursor: pointer;
        }
	input[type=text] {
             	width: 20%%;
            	//padding: 12px 20px;
        	margin: 8px 0;
        	box-sizing: border-box;
    	}

  	</style>
         <script>

	function userUid(){
	var uidReg = /^[0-9]{10}$/;
	var uid = document.getElementById("uid").value;
	var element = document.getElementById("merror");
	if (!(uidReg.test(uid))){
          document.getElementById("merror").innerHTML="Invalid user id...";
          element.style.color="red"
          document.getElementById("uid").value = ""
	return false;
	}
	else
	{
        document.getElementById("merror").innerHTML="";
	return true;
	}
	}

        function userName(){
 	var unameReg = /^[A-Za-z]*$/;
	var uname = document.getElementById("uname").value;
	var element = document.getElementById("ferror");
	if (!(unameReg.test(uname))){
          document.getElementById("ferror").innerHTML="Invalid first Name...";
          element.style.color="red"
          document.getElementById("uname").value = ""
	return false;
	}
	else
	{
        document.getElementById("ferror").innerHTML="";
 	return true
	}
	}

  	function userDob()
	{
    	var dob = document.getElementById("dob").value;
    	var dobReg =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
        var date1=dob.split('/');
        var day=date1[0];
        var month=date1[1];
        var year=date1[2]; 
        
    	var element = document.getElementById("berror");
   	 if ((!dobReg.test(dob)) || day<1 || day>31  || month<1 || month>12 || year<1917 || year>2017){
        document.getElementById("berror").innerHTML="Invalid date of birth...";
        element.style.color="red"
        document.getElementById("dob").value = ""
           return false;
    	}
    	else {
         document.getElementById("berror").innerHTML="";
         return true
    	}
	}
        </script>
        </head>
	<body bgcolor="#6495ED" border="1">

	<h2>Create Event::</h2>

	<form action="createJsonFileForEvent" method="GET" name="form_name" id="form_id" enctype="text/plain">
        	UserId:<br>
	<input type="text" name="uid" placeholder="10 digit number userid" id="uid" onblur="userUid()" required><span id='merror'></span> <br/>
	       Event Name:<br>
	<input type="text" name="name" id="uname" placeholder=" eg. abc" onblur="userName()" required/> <span id = 'ferror'></span></br>
        Enter Date For Event :<br>
        <input type="date" name="dob" id="dob" placeholder="dd/mm/yyyy" max="31/12/1999" onblur="userDob()" required/><span id='berror'> </span><br/>
        <input type="hidden" name="suid" id="suid" value="%s">
	<input type="submit" value="Create">
        <a href="http://localhost/messagingApp/webBackend/composeFrontendPart/fromCompose?uid=%s"> Click Here to go Homepage</a><br><br>

	<br><br>
	</form>

	</body>
	</html>"""%(suserId,urllib.quote_plus(str(suserId)))
     
          

def fromCompose(req):   
   suserId=req.form
   suId=str(suserId)
   suserId=''.join(c for c in suId if '0' <= c <='9')
   return home(suserId) 

