import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from homepage import home
from appBackendForLabelService import getAllLabels,getMessagesFromSorceStore,getAllChild
from showLabel import index,fun2

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def getTableI(data1,data2,data3, row_length,userid):
    show=''
    show+='<head><style>'  
    show+='input[type=submit] {'
    show+=                    'background-color: #4CAF50;'
    show+=                    'border: solid;'
    show+=                    'color: white;'
    show+=                    'padding: 10px 20px;'
    show+=                    'text-align: center;'
    show+=                    'text-decoration: none;'
    show+=                    'display: block;'
    show+=                    'font-size: 16px;'
    show+=                    'border-radius: 2px;'
    show+=                    'latter-spacing:1px;'
    show+=               '} '
    show='</style></head></form>'
    show+= '<table border=1 cellpadding="5" cellspacing="5" bgcolor="#87CEFA">'
    show+='<tr><th>msgFromId</th><th>msgText</th><th>TimeStamp</th></tr>'
    for i in range(0,len(data1)):
        show+= '<tr><td>%d</td>' % data1[i]
        show+= '<td>%s</td>' % data2[i]
        show+= '<td>%s</td></tr>' % data3[i]   
    show+= '</table><br>'
    
    show+='     </form> '
    show+='<a href="http://localhost/messagingApp/webBackend/webBackendForShowLabel.py/label?id=%s">GO Back</a><br><br></form>'
    show+='<a href="http://localhost/messagingApp/webBackend/webBackendForShowLabel/fromLabel?uid=%s">For Home Click Here </a><br><br></form>'
    return show


       
def label(req):
     d={}
     getVarFromFile('/var/www/webPage/messagingApp/config.txt')
     info=req.form
     suserId=info['id'].value
     labels,aplayFor=getAllLabels(suserId)
     d=getAllChild(suserId)
     for parent in labels:
         d[parent]='' 
     labelDisplay=d.keys()
     labels=''
     for l in labelDisplay:
         labels+=','
         labels+=l
     show=''
     show+='<h2>Label Hierarchy</h2><br>'
     show+=index(labelDisplay,d,suserId)  
     show   +='<style>'
     show   +=".submit2{"
     show   +='background-color: orange;'
     show   +='   border: 2px solid;'
     show   +='   border-radius: 2px;'
     show   += '  color: black;'
     show   +='    width: 10em;  height: 2em; top:500px'
     show   +='   text-decoration: none;'
     show   +='   margin: 4px 2px;'
     show+=   'cursor: pointer;'
     show+='}'
     show+=' 	p {position: absolute;left: 1100px;top: 10px; font-size:150%%;margin:20px;}'
     show+='</style>'          
     show+='<body bgcolor="#6495ED"><center>' 
     show+='<form action="http://localhost/messagingApp/webBackend/webBackendForCreateLabel/createLabel" method="post">'
     show+='     <input type="hidden" name="fname" id="fname" value="%s">'%suserId
     show+='     <input type="hidden" name="labels" id="fname" value="%s">'%labels
     show+='    <p><input type="submit" class="submit2" value="create Label!"></p></form></body>'        
     
     return """<html>%s</body</html>"""%(show)

def display(req):
    info=req.form  
    suserId=info['uid'].value 
    if len(info)==1:
        return home(suserId)    
    data=info['edit'].value
    labels,aplayFor=getAllLabels(suserId)
    d=getAllChild(suserId)
    for parent in labels:
         d[parent]='' 
    labelDisplay=d.keys()
    child=[]
    check=[]   
    child=fun2(data,labelDisplay,d,child,check)
    fromId,msg,timeStamp=getMessagesFromSorceStore(suserId,data,child)
    show=''
    show+=getTableI(fromId,msg,timeStamp,len(fromId),suserId)
    return """<html>%s</html>"""%(show%(urllib.quote_plus(str(suserId)),urllib.quote_plus(str(suserId))))

              
def fromLabel(req):
     info=req.form
     suserId=info['uid'].value
     return home(suserId) 
