import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from composeFrontendPart import composeFrontEnd
from datetime import datetime 


def compose(req):
   suserId=req.form
   uid=suserId['id'].value
   return composeFrontEnd(uid)


def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def checkIsPresent(fname,suId):

    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    resDirPath=data.responseDir
    responces = dict ([(f, None) for f in os.listdir (resDirPath)])
    added = [f for f in responces] 
    if fname in added:
       fpath=resDirPath
       fpath+=fname
       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
      
       os.remove(fpath)
       if data1[fname]==1:    
            return """<html>
                	<body>
                	<center><h1>Message send Sucessfully</h1></center>
                	<p><center><a href="%s?id=%s">SEND AGAIN click here</a></center></p>
                	</body>
                	</html>"""%(data.composePath,urllib.quote_plus(str(suId))) 
       else:
           return """<html>
                   <body> <font color="red">UID NOT EXISTS PLESE ENTER CORRECT UID!!!</font> 
                     <br>
                    <a href="%s?id=%s">Go Back</a>
		   </body>	
                   </html>"""%(data.composePath,urllib.quote_plus(str(suId)))        

    return redirect(fname,suId)


def sourceStore(req):        
        info=req.form
        suserId=info['suid'].value
        ruserId=info['name'].value
        text=info['text'].value           
        getVarFromFile('/var/www/webPage/messagingApp/config.txt')
        path=data.targetDirectoryPath
        keys=['suserId','ruserId','msg']
    	values=[suserId,ruserId,text]
    	dictionary = dict(zip(keys, values))
    	data1=json.dumps(dictionary)
        fname="c"
    	fname+=str(ruserId)
    	fname+=".json"
    	path+=fname
    	f=open(path,"w+")
    	f.write("%s"%(data1))
        return checkIsPresent(fname,suserId) 
    	
           
def checkStatus(req):
     info=req.form
     fname=info['fname'].value
     suId=info['suid'].value
     return checkIsPresent(fname,suId)
     
 
     
def redirect(fname,suId):
       return """<html><font color="red">OOPS Response is Not generated !!!</font>
              <body>
             <form action="checkStatus" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="fname" id="fname" value="%s"></p>
              <p><input type="hidden" name="suid" id="suid" value="%s"></p>
             <input type="submit" value="checkStatus" >
             </form>
      
             </body>
             </html>"""%(fname,suId)

