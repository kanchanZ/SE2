
import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from appBackendForInboxAndSentbox import getMessagesFromSorce
from collections import defaultdict
from itertools import chain

def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)



def getChildLabels(suserId,PlabelName):
            cLabels=[]
            users=[]
            getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
            con = lite.connect(data.databaseForWebApp)
  	    cur = con.cursor()
            cur.execute("select childlabel,uids from membersChildLabels where memberid=(?) and plabel=(?)",(suserId,PlabelName,))
            for i in cur:
                 cLabels.append(i[0])
                 users.append(i[1])
                      
            return (cLabels,users)      

def getAllLabels(suserId):
           labels=[]
           data1=[]  
           getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
           con = lite.connect(data.databaseForWebApp)
  	   cur = con.cursor()
           cur.execute("select label,uids from membersLabels where memberid=(?)",(suserId,))
           for i in cur:
                labels.append(i[0])
                data1.append(i)
           d= defaultdict(list)
           for label, userid in data1:
                d[label].append(userid)
           users=dict(d)	
           return (labels,users)

def getAllChild(suserId):
           getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
           con = lite.connect(data.databaseForWebApp)
  	   cur = con.cursor()
           data1=[]
           cur.execute("select plabel,childlabel from membersChildLabels where memberid=(?)",(suserId,))
           for i in cur:
                data1.append(i)
           d={}
           for parent, child in data1:
                d[child]=parent
          
           return dict(d)

def getAllUsersFromParent(memberId,label):  
           users=[]
           getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
           con = lite.connect(data.databaseForWebApp)
  	   cur = con.cursor()
           cur.execute("select uids from membersLabels where memberid=(?) and label=(?)",(memberId,label))
           for u in cur:
               users.append(u)
           return users


def getAllUsersFromChild(users,userId,child,label):
           getVarFromFile('/var/www/webPage/messagingApp/config.txt') 
           con = lite.connect(data.databaseForWebApp)
  	   cur = con.cursor()
           cur.execute("select uids from membersChildLabels where memberid=(?) and childlabel=(?) ",(userId,label))
           for i in cur:
                users.append(i)
           for c in child:
             
             cur.execute("select uids from membersChildLabels where memberid=(?) and childlabel=(?) ",(userId,c))
             for i in cur:
                users.append(i)
           return users
 
def getMessagesFromSorceStore(userId,label,child):
               users=getAllUsersFromParent(userId,label)
               users=getAllUsersFromChild(users,userId,child,label)
               nusers=[]
               for u in users:
                    l=u[0].split(',')
                    l=map(int,l) 
                    nusers.append(l)
               users=list(chain.from_iterable(nusers))
               users=set(users)
               users=list(users)                  
               fids=[]
               msgText=[]
               timeAndDate=[]  
               fromid,messages,timeStamp= getMessagesFromSorce(userId)
               for i in range(0,len(fromid)):
                    if  fromid[i] in users:
                           fids.append(fromid[i])
                           msgText.append(messages[i])
                           timeAndDate.append(timeStamp[i])


               return (fids,msgText,timeAndDate)
   
