import urllib
from homepage import home


def frontEndForLabelServices(check,userId):
        
         if(check=="Subscribe"):
          return """   <html><style>
                       input[type=button], input[type=submit], input[type=reset] {
                       background-color: #4CAF50;
                       border: 2px solid;
                       border-radius: 12px;
                       border-color:pink
                       color: white;
                       padding: 10px 20px;
                       text-decoration: none;
                       margin: 4px 2px;
                       cursor: pointer;
                       } 
                       .service{
                          position: relative;
                          margin: 0 auto;
                          padding: 20px 20px 20px;
                          top:100px; 
                          width: 310px;
                          background: white;
                          border-radius: 15px;
                          border:solid;
                       }
 
                       intput[type=checkbox]{
                        width:100px; 
                        }  

  
                       </style> 
         	       <body bgcolor="#87CEFA">
                       <section class="container">
                       <div class="service">
  
                       <center>
         	       <body>
       	 	       <form action="http://localhost/messagingApp/webBackend/webBackendForServices/getRegister" method="post">
         	       <input type="checkbox" name="label" value="labelservice" checked="checked" required/> Label Service<br>
         	       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="testcase" value="testcasegenration" checked="checked"  >Test Case Generator<br>
                       <p><input type="hidden" name="uid" id="fname" value="%s"></p>
         	       <input type="submit" value="Submit">
                        </center>
         	       </form>
                       
                       </div>
         	       </body>
                
         	       </html>"""%(urllib.quote_plus(str(userId)))

         else:
               return """<html><style>
                       input[type=button], input[type=submit], input[type=reset] {
                       background-color: #4CAF50;
                       border: 2px solid;
                       border-radius: 12px;
                       border-color:pink
                       color: white;
                       padding: 10px 20px;
                       text-decoration: none;
                       margin: 4px 2px;
                       cursor: pointer;
                       } 
                       .service{
                          position: relative;
                          margin: 0 auto;
                          padding: 20px 20px 20px;
                          top:100px; 
                          width: 310px;
                          background: white;
                          border-radius: 15px;
                          border:solid;
                       }
 
                       intput[type=checkbox]{
                        width:100px; 
                        }  

  
                       </style> 
         	       <body bgcolor="#87CEFA">
                       <section class="container">
                       <div class="service">
  
                       <center>
       	 	       <form action="http://localhost/messagingApp/webBackend/webBackendForServices/getUnRegister" method="post">
                       <input type="checkbox" name="label" value="labelservice" checked="checked" required/> Label Service<br>
         	       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="testcase" value="testcasegenration" checked="checked" >Test Case Generator<br>
                       <p><input type="hidden" name="uid" id="fname" value="%s"></p>
         	       <input type="submit" value="Submit">
         	       </form>
                        </div>
         	       </body>
         	       </html>"""%(urllib.quote_plus(str(userId)))



def fromServices(req):
     info=req.form
     suserId=info['uid'].value
     return home(suserId) 
