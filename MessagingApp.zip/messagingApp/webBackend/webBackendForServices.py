import json
import sqlite3 as lite
import imp
import sys
import os, time
import shutil
import re
import hashlib
import urllib
from homepage import home
from  frontEndForServices import frontEndForLabelServices 


def getVarFromFile(filename):
    import imp
    f = open(filename)
    global data
    data = imp.load_source('data', '', f)


def serviceRegistration(req):
     
      info=req.form
      check=info['chk'].value
      userId=info['fname'].value
      return frontEndForLabelServices(check,userId)


def checkIsPresent(fname):

    getVarFromFile('/var/www/webPage/messagingApp/config.txt')
    resDirPath=data.responseDir
    uid=fname[1:11]
    home=data.homePath
    register=data.registrationPath
    responces = dict ([(f, None) for f in os.listdir (resDirPath)])
    added = [f for f in responces] 
    if fname in added:
       fpath=resDirPath
       fpath+=fname
       with open(fpath) as data_file:    
                            data1 = json.load(data_file)
      
       os.remove(fpath)
       if data1[fname]==1 and fname.startswith("s"):    
           return """<html>
                	<body>
                	<center><h1> Service Registration Done Succesfully!!</h1></center>
                	<p><center><form action="fromServicebackend" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="uid" id="uid" value="%s"></p>

             <input type="submit" value="goTOHome" >
             </center></p></form>
                	</body>
                	</html>""" %(urllib.quote_plus(str(uid)))
       elif data1[fname]==1 and fname.startswith("u"):    
           return """<html>
                	<body>
                	<center><h1> Service UnSubscribe  Succesfully!!</h1></center>
                	<p><center><form action="fromServicebackend" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="uid" id="uid" value="%s"></p>

             <input type="submit" value="goToHome" >
             </center></p></form>
                	</body>
                	</html>""" %(urllib.quote_plus(str(uid)))
       else:
           return """
 			<html>
                	<body>
                	<center><h1> Please Select One of the service</h1></center>
                	<p><center><a href="%s"?id="%s">For Go To Home Page click here</a></center></p>
                	</body>
                	</html>""" %(home,urllib.quote_plus(str(uid)))

    return redirect(fname) 

     
def getRegister(req):
       getVarFromFile('/var/www/webPage/messagingApp/config.txt')
       info=req.form
       userId=info['uid'].value
       service=info['label'].value
       keys=['userId','service']
       values=[userId,service]
       dictionary = dict(zip(keys, values))
       data1=json.dumps(dictionary)
       fname="s" 
       fname+=str(userId)
       fname+=".json"
       path=data.targetDirectoryPath
       path+=fname
       f=open(path,"w+")
       f.write("%s"%(data1))
       return checkIsPresent(fname)

  


def checkStatus(req):
     info=req.form
     fname=info['fname'].value
     return checkIsPresent(fname)



def redirect(fname):
       return """<html><font color="red">OOPS Response is Not generated !!!</font>
              <body><center>
             <form action="checkStatus" id="form_id" method="post"  name= "myform">

              <p><input type="hidden" name="fname" id="fname" value="%s"></p>

             <input type="submit" value="checkStatus" >
             </form>
             </center>
             </body>
             </html>"""%(fname)





def getUnRegister(req):
       getVarFromFile('/var/www/webPage/messagingApp/config.txt')
       info=req.form
       userId=info['uid'].value
       service=info['label'].value
       keys=['userId','service']
       values=[userId,service]
       dictionary = dict(zip(keys, values))
       data1=json.dumps(dictionary)
       fname="u" 
       fname+=str(userId)
       fname+=".json"
       path=data.targetDirectoryPath
       path+=fname
       f=open(path,"w+")
       f.write("%s"%(data1))
       return checkIsPresent(fname)



def fromServicebackend(req):
     info=req.form
     userId=info['uid'].value 
     return home(userId)
  
